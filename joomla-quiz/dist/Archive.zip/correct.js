'use strict';

module.exports = {

	CORRECT_EN_GB: [
		"That was good, your answer is correct ",
		"Good guess! Or did you know it, the answer is correct ",
		"your answer is correct ",
		"you chosed the right one, nice ",
		"i knew i can rely on you, that\'s absolutely correct ",
		"you are a <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> master aren\'t you ",
		"Good choice, the answer is right ",
		"you must have already the <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> certificate, well done "
	],
	CORRECT_EN_US: [
		"That was good, your answer is correct ",
		"Good guess! Or did you know it, the answer is correct ",
		"your answer is correct", "you chosed the right one, nice ",
		"i knew i can rely on you, that\'s absolutely correct ",
		"you are a <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> master aren\'t you ",
		"Good choice, the answer is right ",
		"you must have already the <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> certificate, well done ",
		"you should write an article in the <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> Community Magazine about that "
	],
	CORRECT_DE_DE: [
		"Toll gemacht, deine Antwort ist richtig ",
		"Gut geraten! Oder wusstest du es ? ",
		"deine Antwort ist richtig ",
		"du hast dich für die richtige Antwort entschieden ",
		"Ich wusste ich kann mich auf dich verlassen, das ist richtig ",
		"du bist ein <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> Meister oder ? ",
		"Gute Wahl, die Antwort ist richtig",
		"du hast bestimmt schon das <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> Zertifikat, toll gemacht ",
		"Du solltest darüber einen Artikel im <phoneme alphabet=\'ipa\' ph=\'d͡ʒʊmla\'>joomla</phoneme> Community Magazin schreiben "
	]
};

